#include "arraylab.hpp"


void recSelectionSort( int * arr, int * size, int index )
{
    int select = findSmallest( arr, *size, index );
    if ( select > 0 )
    {
        swapper( arr+index, arr+select );
    }
    if ( index < *size-2 )
    {
        recSelectionSort( arr, size, ++index );
    }
}

int findSmallest( int * numset, int size, int index )
{
    // Set foundat to -1 to start. This acts as a false if there is no smaller
    // number found.
    int smallest = numset[index], foundat = -1;
    for ( int i=index; i<size; i++ )
    {
        if ( smallest > numset[i] )
        {
            smallest = numset[i];
            foundat = i;
        }
    }
    // Return just the index where the value is found. This can be used in the swapper later.
    return foundat;
}

void swapper( int * left, int * right )
{
    int temp = *left;
    *left = *right;
    *right = temp;
}
