#include <string>

#ifndef __CAR_LIST__
#define __CAR_LIST__

#include "Car.h"

struct Garage {
    Garage * next;
    Car * car;
};

class CarList {
    Garage * bay;
    bool recFind(Garage * ptr, Car & fnd);
public:
    CarList();
    ~CarList();
    void addCar( string make, string color, int year );
    void clearCars(Garage * cars);
    std::string displayList();
    Car * removeHead();
    bool findCar(string make, string color, int year);
    void recDestruct(Garage * ptr);
};

#endif // __CAR_LIST__
