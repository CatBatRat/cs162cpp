#include <string>
#include "CreditCard.hpp"

using std::string;


CreditCard::CreditCard( string F, string L, string A, int CN, double LMT ):
    cardNum(CN), creditLimit(LMT), balance(0)
    { setOwnerName( F, L ); setAddress(A); }

void CreditCard::setOwnerName( string F, string L ) {
    pe.setFirstName(F);
    pe.setLastName(L);
}
string CreditCard::getOwnerName() {
    return pe.getFirstName() + " " + pe.getLastName();
}

void CreditCard::setCreditLimit( double climit ) {
    if( climit >= 0 )
        creditLimit = climit;
    else
        creditLimit = 0;
}

bool CreditCard::makeCharge( double charge ) {
    bool valid = false;
    if( charge > 0 and charge+balance<creditLimit ) {
        balance += charge;
        valid = true;
    }
    return valid;
}

bool CreditCard::payBalance( double pay ) {
    bool valid = false;
    if( pay > 0 ) {
        balance -= pay;
        valid = true;
    }
    return valid;
}
