
#include <string>

#ifndef __PERSON__
#define __PERSON__

using std::string;

class Person {
private:
    string firstName;
    string lastName;
    string address;
public:
    // Default constructor sets all values to "".
    Person();
    Person( string F, string L, string A );
    // Sets and gets firstName and lastName.
    void   setFirstName(string F);
    string getFirstName();
    void   setLastName(string L);
    string getLastName();
    // Sets and gets address.
    void   setAddress(string A);
    string getAddress();
};

#endif //__PERSON__
