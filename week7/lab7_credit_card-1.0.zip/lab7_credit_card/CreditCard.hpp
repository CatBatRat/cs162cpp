#include <string>

#ifndef __CREDIT_CARD__
#define __CREDIT_CARD__

#include "Person.hpp"

using std::string;

class CreditCard {
private:
    Person pe;
    int     cardNum;
    double  creditLimit;
    double  balance;
public:
    CreditCard();
    CreditCard( string F, string L, string A, int CN, double LMT );
    // Set and gets first and last of Person.
    void   setOwnerName( string fName, string lName ); // v/
    string getOwnerName();
    // Sets and gets address of Person.
    void   setAddress( string addrs );
    string getAddress();
    // Sets and gets cardNumber.
    void   setCardNumber( int cNum );
    int    getCardNumber();
    // Sets and gets creditLimit.
    void   setCreditLimit( double climit );
    double getCreditLimit();
    // Adds charge to balance.
    bool   makeCharge( double charge );
    // Decreases balance based on payment.
    bool   payBalance( double pay );
    // returns the current balance on the card.
    double getBalance();
};

#endif //__CREDIT_CARD__
