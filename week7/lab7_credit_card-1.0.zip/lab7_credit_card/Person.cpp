#include <string>
#include "Person.hpp"

Person::Person():
    firstName(""), lastName(""), address("") {}
Person::Person( string F, string L, string A ):
    firstName(F), lastName(L), address(A) {}

void Person::setFirstName(string F) {
    firstName = F;
}
string Person::getFirstName() {
    return firstName;
}

void Person::setLastName(string L) {
    lastName = L;
}
string Person::getLastName() {
    return lastName;
}

void Person::setAddress(string A) {
    address = A;
}
string Person::getAddress() {
    return address;
}
