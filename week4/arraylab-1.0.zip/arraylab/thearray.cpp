#include <iostream>
#include <iomanip>
#include "arraylab.hpp"

using namespace std;

int getSize()
{
    int size = 0;
    cout << "Please enter a number between " << AMIN << " and " << AMAX << "\n"
         << "This will be the length of the list of\n"
         << "numbers to be sorted and searched." << endl;
    do
    {
        cout << "\nPlease enter your number.\n"
             << "It must be in the range " << AMIN << " to " << AMAX << endl;
        cin >> size;
        cin.clear();
        cin.ignore(1000000, '\n');
    } while( size < AMIN or size > AMAX );
    cout << "Setting size of the number list to " << size << endl;
    return size;
}

int * makeArray( int * size )
{
    int *arr = new int[*size];
    for ( int l=0; l<*size; l++ )
    {
        *(arr+l) = rand() % RMAX + RMIN;
    }
    return arr;
}

void displayArray( int arr[], int * size, int line )
{
    for ( int l=0; l<*size; l++ )
    {
        if( !( l % line and l > 0 ) )
            cout << endl;
        cout << *(arr+l) << " ";
    }
    cout << endl;
}
