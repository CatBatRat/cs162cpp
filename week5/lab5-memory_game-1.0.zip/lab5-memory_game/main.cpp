#include <iostream>
#include <random>
#include "memgame.hpp"

using namespace std;

int main()
{
    srand(static_cast<int>(time(nullptr)));

    Game board;

    do
    {

        cout << "Enter the size of the board or type 0 to use the default." << endl;
        int size;
        cin >> size;
        cinClear();
        if( size % 2 == 0 and size != 0 )
            board.size = size;
        else if( size == 0 )
            board.size = 4;
        else
        {
            board.size = 4;
            cout << "Must select a number that will result in an\n"
                    "even number of cards.\n"
                    "defaulting to 4." << endl;
            waitEnter();
        }
        board.grid = makeBoard( board );
        board.checked = makeChecked( board );
        do
        {
            displayBoard( board );
            cout << "Pick the first card you would like to flip." << endl;
            getMove( board );
            displayBoard( board );
            cout << "Now pick the second card." << endl;
            getMove( board );
            displayBoard( board );
            checkMove( board );
        } while( !( checkWin( board ) ) );
        displayBoard( board );
        cout << "Yay! You won the game!!!" << endl;

        delete[] board.grid;
        delete[] board.checked;
    } while( playAgain( board ) );

    return 0;
}
